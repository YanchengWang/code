from ema_pytorch.ema_pytorch import EMA
